# 今天中午吃什麼？｜團隊共用網頁版

這是一個可部署到 GitHub Pages 的靜態網頁，使用 Supabase 作為共用資料庫。所有同事打開同一網址，就會看到相同的餐廳清單及當日抽籤結果。

## 功能
- 台灣時區自動顯示日期、星期。
- 週一至週五抽籤；同一週不重複。
- 多人同時抽籤時，資料庫會鎖定當週抽籤流程，確保同一天只有一個結果。
- 所有人共用餐廳名單，可新增、編輯、刪除。
- 顯示 Google Maps 與「只收現金」標記。
- 每 30 秒自動同步一次資料。

## 部署前置作業（約 10–15 分鐘）
需要一個 Supabase 帳號及 GitHub 帳號。以下是一次性設定。

### 1. 建立 Supabase 專案
1. 到 https://supabase.com/ 建立免費專案。
2. 專案建立後，進入左側 **SQL Editor**。
3. 開啟本資料夾的 `supabase-setup.sql`，全選複製，貼進 SQL Editor，按 **Run**。
4. 到 **Project Settings → API**（或 API Keys）取得：
   - Project URL
   - anon / publishable public key
   請勿使用 `service_role` 或 secret key。

### 2. 設定網頁連線
1. 用文字編輯器開啟 `index.html`。
2. 找到最上方這兩行：
   `const SUPABASE_URL = "YOUR_SUPABASE_URL";`
   `const SUPABASE_ANON_KEY = "YOUR_SUPABASE_ANON_KEY";`
3. 分別貼上 Supabase Project URL 及 anon / publishable public key。
4. 儲存檔案。

### 3. 發佈到 GitHub Pages
1. 到 https://github.com/ 建立一個新的 repository，例如 `team-lunch-picker`。
2. 將 `index.html` 上傳到 repository 根目錄。
3. 到 repository 的 **Settings → Pages**。
4. 在 **Build and deployment** 選擇 `Deploy from a branch`。
5. Branch 選 `main`、資料夾選 `/ (root)`，按 Save。
6. 等待 GitHub Pages 部署完成，會出現一個網址，格式類似：
   `https://你的帳號.github.io/team-lunch-picker/`
7. 把這個網址貼到同事 LINE 群組即可。

## 使用方式
- 抽籤：同事打開網頁按「抽出今天的午餐」，所有人看到同一結果。
- 新增：輸入店名、Google Maps 網址，勾選是否只收現金，再按新增。
- 編輯：在餐廳清單點「編輯」，修改後儲存。
- 刪除：在餐廳清單點「刪除」。
- 名單修改與抽籤結果存在 Supabase，不是某一位同事的手機。

## 權限與安全提醒
此範例採「知道網址即可共同使用」的公開協作模式；匿名訪客可以讀取、增加、修改、刪除餐廳，亦可呼叫抽籤功能。這對小型同事午餐工具最簡單，但**不要放入私人或敏感資料**，也不要把此模式直接用於公司正式內部系統。

前端只能使用 Supabase 的 anon / publishable key；絕對不要放 service_role / secret key。若希望限制只有公司同事能使用，下一版應加上 Supabase Auth（例如公司信箱登入）及角色權限。

## 備註
- 抽籤週期以台灣時間週一開始計算。
- 週末不開放抽籤。
- 每週每間餐廳最多中選一次；若餐廳數量不足，當週抽完即停止。
- `supabase-setup.sql` 可重複執行；初始餐廳以名稱避免重複匯入。
