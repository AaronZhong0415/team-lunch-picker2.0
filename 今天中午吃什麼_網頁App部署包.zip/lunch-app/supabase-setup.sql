-- 在 Supabase Dashboard > SQL Editor 執行整份 SQL
create extension if not exists pgcrypto;

create table if not exists public.restaurants (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(trim(name)) between 1 and 80),
  google_maps_url text not null,
  cash_only boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.lunch_draws (
  id uuid primary key default gen_random_uuid(),
  draw_date date not null unique,
  week_start date not null,
  restaurant_id uuid not null references public.restaurants(id) on delete restrict,
  created_at timestamptz not null default now()
);

alter table public.restaurants enable row level security;
alter table public.lunch_draws enable row level security;

-- 此範例採「知道網址即可共同使用」的公開協作模式。
-- 正式公司內部使用，建議再加登入驗證及管理者權限。
drop policy if exists "public read restaurants" on public.restaurants;
create policy "public read restaurants" on public.restaurants for select to anon, authenticated using (true);
drop policy if exists "public add restaurants" on public.restaurants;
create policy "public add restaurants" on public.restaurants for insert to anon, authenticated with check (true);
drop policy if exists "public update restaurants" on public.restaurants;
create policy "public update restaurants" on public.restaurants for update to anon, authenticated using (true) with check (true);
drop policy if exists "public delete restaurants" on public.restaurants;
create policy "public delete restaurants" on public.restaurants for delete to anon, authenticated using (true);
drop policy if exists "public read draws" on public.lunch_draws;
create policy "public read draws" on public.lunch_draws for select to anon, authenticated using (true);

grant usage on schema public to anon, authenticated;
grant select, insert, update, delete on public.restaurants to anon, authenticated;
grant select on public.lunch_draws to anon, authenticated;

-- 以資料庫鎖確保多人同時按下抽籤，也只會產生一個當日結果。
create or replace function public.draw_lunch_today()
returns json
language plpgsql
security definer
set search_path = public
as $$
declare
  taipei_today date := (now() at time zone 'Asia/Taipei')::date;
  monday date := date_trunc('week', (now() at time zone 'Asia/Taipei'))::date;
  existing_draw public.lunch_draws%rowtype;
  picked public.restaurants%rowtype;
begin
  if extract(isodow from taipei_today) > 5 then
    raise exception '週末不開放抽籤';
  end if;

  perform pg_advisory_xact_lock(hashtext('team_lunch_draw_' || monday::text));

  select * into existing_draw
  from public.lunch_draws
  where draw_date = taipei_today;

  if found then
    select * into picked from public.restaurants where id = existing_draw.restaurant_id;
    return json_build_object('id',picked.id,'name',picked.name,'google_maps_url',picked.google_maps_url,'cash_only',picked.cash_only);
  end if;

  select r.* into picked
  from public.restaurants r
  where not exists (
    select 1 from public.lunch_draws d
    where d.week_start = monday and d.restaurant_id = r.id
  )
  order by random()
  limit 1;

  if not found then
    raise exception '本週可抽餐廳已用完，請新增餐廳或等下週';
  end if;

  insert into public.lunch_draws(draw_date,week_start,restaurant_id)
  values(taipei_today,monday,picked.id);

  return json_build_object('id',picked.id,'name',picked.name,'google_maps_url',picked.google_maps_url,'cash_only',picked.cash_only);
end;
$$;

revoke all on function public.draw_lunch_today() from public;
grant execute on function public.draw_lunch_today() to anon, authenticated;

-- 初始 34 間餐廳（重複執行不會重複新增同名店）
insert into public.restaurants(name,google_maps_url,cash_only)
select v.name,v.url,v.cash_only
from (values
('滇味廚房','https://maps.app.goo.gl/6W35gAcGP4ZaRDbAA?g_st=ic',true),
('武鼎越豐','https://maps.app.goo.gl/QUHzFGYaM8ZaHCpa7?g_st=ic',true),
('皇泰泰','https://maps.app.goo.gl/wqhNd3kbTijpCevt5?g_st=ic',false),
('誠記河粉','https://maps.app.goo.gl/fJx4jwLPN7kZs61g7?g_st=ic',false),
('胡饕米粉湯','https://maps.app.goo.gl/w1yfheYi7Fk3Sqcs7?g_st=ic',false),
('亞米小廚','https://maps.app.goo.gl/wVPV3ykLmbTbecWs8?g_st=ic',false),
('瑞記海南雞飯','https://maps.app.goo.gl/1BVg8qHYGuhiV7nD7?g_st=ic',false),
('半島牛肉麵','https://maps.app.goo.gl/RsfbPvbHRWojTNUC8?g_st=ic',true),
('立志和食','https://maps.app.goo.gl/D45cz9ZXzZGn8LcD9?g_st=ic',false),
('壽司郎永春店','https://maps.app.goo.gl/xVL7K2JKuvuehSuR8?g_st=ic',false),
('香廚炒飯','https://maps.app.goo.gl/psRBD4ZSi4sf8NhK6?g_st=ic',true),
('蕨食堂','https://maps.app.goo.gl/NAqezo3J7P6nZ3W3A?g_st=ic',true),
('道食樂','https://maps.app.goo.gl/3aWS7WZeDhkQazKz6?g_st=ic',true),
('富察家拉麵','https://maps.app.goo.gl/b9TNHnA2x4aGhAud6?g_st=ic',true),
('無敵水餃','https://maps.app.goo.gl/RkLigJgNBhaZe93K7?g_st=ic',false),
('品豐小食','https://maps.app.goo.gl/rAJ6UKAoM88kAr4T7?g_st=ic',true),
('公園餡餅粥','https://maps.app.goo.gl/h2hQ3KTNhKaSCKsC9?g_st=ic',true),
('麵舖','https://maps.app.goo.gl/SUiiNjTv9XR58RjUA?g_st=ic',true),
('NENE CHICKEN永春店','https://maps.app.goo.gl/Hu9m6y9ow35jKN8n7?g_st=ic',false),
('卷卷- Cuốn Cuộn','https://maps.app.goo.gl/qyqCndqxZfQ3cHrs9?g_st=ic',false),
('新光三越 A8','https://maps.app.goo.gl/W2RLLVFVkJyeH94s6?g_st=ic',false),
('Dream plaza','https://maps.app.goo.gl/YjBZ2C7q9qFK2cmR9?g_st=ic',false),
('八方雲集信義松農店','https://maps.app.goo.gl/4G7J11oa2hmnc3cJ7?g_st=ic',false),
('泰緬姐妹小館忠孝店','https://maps.app.goo.gl/sTgqssiXW8pViowA7?g_st=ic',true),
('新娘子小吃忠孝店','https://maps.app.goo.gl/eTPaBbQqJvzysmCJ8?g_st=ic',false),
('圈粉舖子忠孝店','https://maps.app.goo.gl/qWiAQVZ4cfs6WAZr7?g_st=ic',false),
('沅鄉台南虱目魚店','https://maps.app.goo.gl/eYvVcoR6HSr5Npwa6?g_st=ic',false),
('市府海鮮麵疙瘩','https://maps.app.goo.gl/XM32scgFn4YV5MDu8?g_st=ic',true),
('Banh Mi邦米手作創意法國麵包','https://maps.app.goo.gl/isTxiN2eoJNnxptK9?g_st=ic',false),
('阿弟仔大腸麵線','https://maps.app.goo.gl/hNxDMSFJaXeFAUc96?g_st=ic',true),
('食徒頂即鍋永吉店','https://maps.app.goo.gl/KuWdFUFhzfeo1KDq8?g_st=ic',false),
('新牛屋厚切牛排永吉店','https://maps.app.goo.gl/AZcuHTh6HBpSo6qr5?g_st=ic',false),
('初殿鍋物永春店','https://maps.app.goo.gl/nftz1q16jMLmLxKD7?g_st=ic',false),
('Le Mani琢手咖啡信義店','https://maps.app.goo.gl/qn2ebK92zSZf1w6J8?g_st=ic',false)
) as v(name,url,cash_only)
where not exists (select 1 from public.restaurants r where r.name=v.name);
